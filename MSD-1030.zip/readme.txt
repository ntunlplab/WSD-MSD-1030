This readme would instruct every file in this directory.

1, MSD-1030.txt:
    * It's an evaluation dataset we proposed for sense embedding models.
    * This file is separated by a tab.
    * For each line, it contains (w1    w2    "mean of scores"    [scores])
    * Users could use the means of scores to calculate Spearman and Pearson correlation of their embedding models. 

2, guideline.html:
    * It is the template HTML we created for annotators.
    * Annotators would see this webpage when answering their rating of word pair.